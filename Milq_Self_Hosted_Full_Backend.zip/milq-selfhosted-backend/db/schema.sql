create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  password_hash text not null,
  display_name text,
  role text not null default 'user' check (role in ('user','premium','staff','admin')),
  is_suspended boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  description text,
  runtime text not null default 'nodejs',
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists projects_user_idx on projects(user_id);

create table if not exists bot_deployments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  deployment_id text not null unique,
  name text not null,
  runtime text,
  state text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists bot_deployments_user_idx on bot_deployments(user_id);
create index if not exists bot_deployments_project_idx on bot_deployments(project_id);

create table if not exists bot_env (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  deployment_id text not null references bot_deployments(deployment_id) on delete cascade,
  key text not null,
  is_secret boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(deployment_id, key)
);

create table if not exists bot_logs (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  deployment_id text not null references bot_deployments(deployment_id) on delete cascade,
  stream text not null default 'system',
  content text not null,
  created_at timestamptz not null default now()
);

create index if not exists bot_logs_dep_created_idx on bot_logs(deployment_id, created_at desc);

create table if not exists api_audit_logs (
  id bigserial primary key,
  user_id uuid references users(id) on delete set null,
  action text not null,
  resource_type text,
  resource_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists audit_user_created_idx on api_audit_logs(user_id, created_at desc);

create table if not exists app_files (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  relative_path text not null,
  storage_path text not null,
  size_bytes bigint not null default 0,
  mime_type text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists app_files_user_project_idx on app_files(user_id, project_id);

create table if not exists usage_counters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  metric text not null,
  value bigint not null default 0,
  period_start date not null,
  period_end date not null,
  unique(user_id, metric, period_start, period_end)
);
