# Milq.ai Self-Hosted Backend

This version runs almost everything on your own server.

Architecture:

Swift iOS App
-> Milq Backend
-> PostgreSQL Database
-> Local File Storage
-> Bot-Hosting.net API
-> Discord Bots

Supabase is not required for the core system.

## Included

- Node.js backend API
- PostgreSQL database
- User registration/login
- JWT authentication
- User roles
- Projects
- Bot deployment ownership
- Bot creation
- Bot start/stop/restart/kill
- Bot logs
- Bot resource usage
- Environment variable management
- Bot file management
- Apply/restart workflow
- Local server file storage
- Audit logs
- Usage table foundation
- Docker
- Docker Compose
- Persistent PostgreSQL volume
- Persistent file-storage volume

## Fast setup

1. Extract the ZIP on your server.

2. Create `.env`:

```bash
cp .env.example .env
```

3. Edit `.env` and set at least:

```text
POSTGRES_PASSWORD=your-strong-database-password
JWT_SECRET=your-long-random-secret
BOT_HOSTING_API_KEY=your-bot-hosting-api-key
```

For Docker Compose, the environment variables can be placed in `.env` beside `docker-compose.yml`.

4. Start everything:

```bash
docker compose up -d --build
```

5. Open:

```text
http://YOUR_SERVER_IP:3000/health
```

You should receive:

```json
{"ok":true}
```

## Services

`postgres`
- PostgreSQL database
- persistent Docker volume

`backend`
- Milq REST API
- JWT auth
- Bot-Hosting.net integration
- persistent file storage

## Main API

Authentication:

- POST `/auth/register`
- POST `/auth/login`
- GET `/auth/me`

Projects:

- GET `/api/projects`
- POST `/api/projects`

Bots:

- GET `/api/deployments`
- POST `/api/deployments`
- GET `/api/deployments/:id`
- POST `/api/deployments/:id/power`
- GET `/api/deployments/:id/logs`
- GET `/api/deployments/:id/resources`

Bot environment variables:

- POST `/api/deployments/:id/env`
- DELETE `/api/deployments/:id/env/:key`

Bot files:

- GET `/api/deployments/:id/files/tree`
- POST `/api/deployments/:id/files/content`
- POST `/api/deployments/:id/apply`

Server storage:

- POST `/api/storage/upload`
- GET `/api/storage/files`

Audit:

- GET `/api/audit`

## Swift authentication

Register/login returns:

```json
{
  "user": {},
  "token": "JWT_TOKEN"
}
```

Use the token on protected requests:

```http
Authorization: Bearer JWT_TOKEN
```

## Database tables

- users
- projects
- bot_deployments
- bot_env
- bot_logs
- api_audit_logs
- app_files
- usage_counters

## Security

Never ship these in the Swift app:

- PostgreSQL password
- JWT secret
- Bot-Hosting.net API key

Only the backend server should know them.

## HTTPS

For production, put Caddy, Nginx or Cloudflare in front of port 3000 and use HTTPS.

Example public API:

```text
https://api.yourdomain.com
```

Your Swift app should call that HTTPS URL instead of the raw server IP.

## Important

This package stores app/database/file data on your own server, but actual Discord bot processes are still hosted through Bot-Hosting.net.

If you later want everything fully self-hosted too, replace the Bot-Hosting.net adapter with a Docker worker system.
