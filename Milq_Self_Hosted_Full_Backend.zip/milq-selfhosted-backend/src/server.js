import express from "express";
import cors from "cors";
import helmet from "helmet";
import bcrypt from "bcryptjs";
import multer from "multer";
import fs from "fs";
import path from "path";
import { z } from "zod";

import { config } from "./config.js";
import { query } from "./lib/db.js";
import { signToken } from "./lib/auth.js";
import { requireAuth } from "./middleware/auth.js";
import { bhRequest, BotHostingError } from "./lib/botHosting.js";

fs.mkdirSync(config.storageDir, { recursive: true });

const upload = multer({
  dest: config.storageDir,
  limits: { fileSize: 25 * 1024 * 1024 }
});

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: config.maxJsonBody }));

const allowAll = config.corsOrigins.includes("*");
app.use(cors({
  origin: allowAll ? true : (origin, cb) => {
    if (!origin || config.corsOrigins.includes(origin)) return cb(null, true);
    cb(new Error("CORS origin denied"));
  }
}));

app.get("/", (_req, res) => {
  res.json({ service: "Milq Self-Hosted Backend", status: "online", version: "1.0.0" });
});
app.get("/health", (_req, res) => res.json({ ok: true, time: new Date().toISOString() }));

const registerSchema = z.object({
  email: z.string().email().max(320),
  password: z.string().min(8).max(200),
  displayName: z.string().max(100).optional()
});

app.post("/auth/register", async (req, res, next) => {
  try {
    const b = registerSchema.parse(req.body);
    const hash = await bcrypt.hash(b.password, 12);

    const { rows } = await query(
      `insert into users(email, password_hash, display_name)
       values($1,$2,$3)
       returning id,email,display_name,role,is_suspended,created_at`,
      [b.email.toLowerCase(), hash, b.displayName || null]
    );

    const user = rows[0];
    res.status(201).json({ user, token: signToken(user) });
  } catch (e) { next(e); }
});

app.post("/auth/login", async (req, res, next) => {
  try {
    const body = z.object({
      email: z.string().email(),
      password: z.string().min(1)
    }).parse(req.body);

    const { rows } = await query(
      "select * from users where email=$1 limit 1",
      [body.email.toLowerCase()]
    );
    const user = rows[0];

    if (!user || !(await bcrypt.compare(body.password, user.password_hash))) {
      return res.status(401).json({ error: "invalid_credentials" });
    }
    if (user.is_suspended) return res.status(403).json({ error: "account_suspended" });

    const safeUser = {
      id: user.id,
      email: user.email,
      display_name: user.display_name,
      role: user.role
    };
    res.json({ user: safeUser, token: signToken(safeUser) });
  } catch (e) { next(e); }
});

app.get("/auth/me", requireAuth, (req, res) => res.json({ user: req.user }));

app.use("/api", requireAuth);

app.get("/api/projects", async (req, res, next) => {
  try {
    const { rows } = await query(
      "select * from projects where user_id=$1 order by created_at desc",
      [req.user.id]
    );
    res.json({ projects: rows });
  } catch (e) { next(e); }
});

app.post("/api/projects", async (req, res, next) => {
  try {
    const b = z.object({
      name: z.string().min(1).max(100),
      description: z.string().max(500).optional(),
      runtime: z.string().max(50).default("nodejs")
    }).parse(req.body);

    const { rows } = await query(
      `insert into projects(user_id,name,description,runtime)
       values($1,$2,$3,$4) returning *`,
      [req.user.id, b.name, b.description || null, b.runtime]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

async function ownedDeployment(userId, deploymentId) {
  const { rows } = await query(
    "select * from bot_deployments where user_id=$1 and deployment_id=$2 limit 1",
    [userId, deploymentId]
  );
  return rows[0];
}

async function audit(userId, action, resourceType, resourceId, metadata = {}) {
  await query(
    `insert into api_audit_logs(user_id,action,resource_type,resource_id,metadata)
     values($1,$2,$3,$4,$5)`,
    [userId, action, resourceType, resourceId, JSON.stringify(metadata)]
  );
}

app.get("/api/deployments", async (req, res, next) => {
  try {
    const { rows } = await query(
      "select * from bot_deployments where user_id=$1 order by created_at desc",
      [req.user.id]
    );
    res.json({ deployments: rows });
  } catch (e) { next(e); }
});

app.post("/api/deployments", async (req, res, next) => {
  try {
    const b = z.object({
      projectId: z.string().uuid().optional(),
      name: z.string().min(1).max(80),
      description: z.string().max(500).optional(),
      runtime: z.string().default("nodejs"),
      runtimeVersion: z.union([z.string(), z.number()]).optional(),
      ramMB: z.number().int().positive().optional(),
      cpuPct: z.number().positive().optional(),
      storageMB: z.number().int().positive().optional(),
      githubRepo: z.string().max(300).optional(),
      branch: z.string().max(200).optional()
    }).parse(req.body);

    if (b.projectId) {
      const p = await query("select id from projects where id=$1 and user_id=$2", [b.projectId, req.user.id]);
      if (!p.rows[0]) return res.status(404).json({ error: "project_not_found" });
    }

    const payload = {
      name: b.name,
      description: b.description,
      runtime: b.runtime,
      source: b.githubRepo ? "github" : "blank"
    };
    for (const k of ["runtimeVersion","ramMB","cpuPct","storageMB","githubRepo","branch"]) {
      if (b[k] !== undefined) payload[k] = b[k];
    }

    const created = await bhRequest("/deployments", { method: "POST", body: payload });

    await query(
      `insert into bot_deployments(user_id,project_id,deployment_id,name,runtime,state,metadata)
       values($1,$2,$3,$4,$5,$6,$7)`,
      [
        req.user.id, b.projectId || null, created.id, created.name || b.name,
        created.runtime || b.runtime, created.state || null, JSON.stringify(created)
      ]
    );

    await audit(req.user.id, "deployment.create", "deployment", created.id, { name: b.name });
    res.status(201).json(created);
  } catch (e) { next(e); }
});

app.get("/api/deployments/:id", async (req, res, next) => {
  try {
    const own = await ownedDeployment(req.user.id, req.params.id);
    if (!own) return res.status(404).json({ error: "deployment_not_found" });

    const result = await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}`);
    await query(
      `update bot_deployments set name=$1,runtime=$2,state=$3,metadata=$4,updated_at=now()
       where deployment_id=$5 and user_id=$6`,
      [result.name || own.name, result.runtime || own.runtime, result.state || null, JSON.stringify(result), req.params.id, req.user.id]
    );
    res.json(result);
  } catch (e) { next(e); }
});

app.post("/api/deployments/:id/power", async (req, res, next) => {
  try {
    const own = await ownedDeployment(req.user.id, req.params.id);
    if (!own) return res.status(404).json({ error: "deployment_not_found" });

    const b = z.object({
      action: z.enum(["start","stop","restart","kill"]),
      waitSeconds: z.number().int().min(0).max(90).optional()
    }).parse(req.body);

    const result = await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/power`, {
      method: "POST", body: b
    });

    await query(
      "update bot_deployments set state=$1, updated_at=now() where user_id=$2 and deployment_id=$3",
      [result?.state || b.action, req.user.id, req.params.id]
    );
    await audit(req.user.id, `deployment.${b.action}`, "deployment", req.params.id);
    res.json(result);
  } catch (e) { next(e); }
});

app.get("/api/deployments/:id/logs", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const q = req.query.lines ? `?lines=${encodeURIComponent(String(req.query.lines))}` : "";
    const result = await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/logs${q}`);
    res.json(result);
  } catch (e) { next(e); }
});

app.get("/api/deployments/:id/resources", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });
    res.json(await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/resources`));
  } catch (e) { next(e); }
});

app.post("/api/deployments/:id/env", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const b = z.object({
      key: z.string().regex(/^[A-Za-z_][A-Za-z0-9_]*$/).max(100),
      value: z.string().max(20000),
      secret: z.boolean().default(true)
    }).parse(req.body);

    const result = await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/env`, {
      method: "POST", body: b
    });

    await query(
      `insert into bot_env(user_id,deployment_id,key,is_secret)
       values($1,$2,$3,$4)
       on conflict(deployment_id,key)
       do update set is_secret=excluded.is_secret, updated_at=now()`,
      [req.user.id, req.params.id, b.key, b.secret]
    );

    await audit(req.user.id, "deployment.env.set", "deployment", req.params.id, { key: b.key });
    res.json(result);
  } catch (e) { next(e); }
});

app.delete("/api/deployments/:id/env/:key", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const result = await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/env/${encodeURIComponent(req.params.key)}`, {
      method: "DELETE"
    });

    await query("delete from bot_env where user_id=$1 and deployment_id=$2 and key=$3",
      [req.user.id, req.params.id, req.params.key]);
    res.json(result);
  } catch (e) { next(e); }
});

app.get("/api/deployments/:id/files/tree", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const params = new URLSearchParams();
    if (req.query.path) params.set("path", String(req.query.path));
    if (req.query.depth) params.set("depth", String(req.query.depth));
    const q = params.toString() ? `?${params}` : "";
    res.json(await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/files/tree${q}`));
  } catch (e) { next(e); }
});

app.post("/api/deployments/:id/files/content", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const b = z.object({
      path: z.string().min(1).max(1024),
      content: z.string().max(5_000_000),
      mode: z.enum(["overwrite","append"]).default("overwrite")
    }).parse(req.body);

    res.json(await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/files/content`, {
      method: "POST", body: b
    }));
  } catch (e) { next(e); }
});

app.post("/api/deployments/:id/apply", async (req, res, next) => {
  try {
    if (!(await ownedDeployment(req.user.id, req.params.id)))
      return res.status(404).json({ error: "deployment_not_found" });

    const restart = req.body?.restart !== false;
    const waitSeconds = Number.isInteger(req.body?.waitSeconds) ? Math.max(0, Math.min(90, req.body.waitSeconds)) : 20;

    res.json(await bhRequest(`/deployments/${encodeURIComponent(req.params.id)}/apply`, {
      method: "POST",
      body: { restart, waitSeconds }
    }));
  } catch (e) { next(e); }
});

app.post("/api/storage/upload", upload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "missing_file" });

    const projectId = req.body.projectId || null;
    if (projectId) {
      const p = await query("select id from projects where id=$1 and user_id=$2", [projectId, req.user.id]);
      if (!p.rows[0]) {
        fs.unlinkSync(req.file.path);
        return res.status(404).json({ error: "project_not_found" });
      }
    }

    const relativePath = req.file.originalname;
    const { rows } = await query(
      `insert into app_files(user_id,project_id,relative_path,storage_path,size_bytes,mime_type)
       values($1,$2,$3,$4,$5,$6) returning *`,
      [req.user.id, projectId, relativePath, req.file.path, req.file.size, req.file.mimetype]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

app.get("/api/storage/files", async (req, res, next) => {
  try {
    const { rows } = await query(
      "select id,project_id,relative_path,size_bytes,mime_type,created_at from app_files where user_id=$1 order by created_at desc",
      [req.user.id]
    );
    res.json({ files: rows });
  } catch (e) { next(e); }
});

app.get("/api/audit", async (req, res, next) => {
  try {
    const { rows } = await query(
      "select * from api_audit_logs where user_id=$1 order by created_at desc limit 200",
      [req.user.id]
    );
    res.json({ logs: rows });
  } catch (e) { next(e); }
});

app.use((_req, res) => res.status(404).json({ error: "not_found" }));

app.use((error, _req, res, _next) => {
  console.error(error);

  if (error instanceof z.ZodError) {
    return res.status(400).json({
      error: "invalid_request",
      details: error.issues.map(i => ({ path: i.path.join("."), message: i.message }))
    });
  }

  if (error instanceof BotHostingError) {
    return res.status(error.status || 502).json({
      error: "bot_hosting_error",
      details: error.payload ?? error.message
    });
  }

  if (error?.code === "23505") {
    return res.status(409).json({ error: "already_exists" });
  }

  res.status(500).json({ error: "internal_server_error" });
});

app.listen(config.port, "0.0.0.0", () => {
  console.log(`Milq backend listening on ${config.port}`);
});
