import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { pool } from "./lib/db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const sql = fs.readFileSync(path.join(__dirname, "../db/schema.sql"), "utf8");

try {
  await pool.query(sql);
  console.log("Database migration complete.");
} finally {
  await pool.end();
}
