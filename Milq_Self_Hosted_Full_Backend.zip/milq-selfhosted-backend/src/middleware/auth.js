import { verifyToken } from "../lib/auth.js";
import { query } from "../lib/db.js";

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) {
      return res.status(401).json({ error: "missing_authorization" });
    }

    const token = header.slice(7).trim();
    const payload = verifyToken(token);

    const { rows } = await query(
      "select id, email, display_name, role, is_suspended from users where id = $1 limit 1",
      [payload.sub]
    );

    const user = rows[0];
    if (!user) return res.status(401).json({ error: "invalid_user" });
    if (user.is_suspended) return res.status(403).json({ error: "account_suspended" });

    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "invalid_token" });
  }
}
