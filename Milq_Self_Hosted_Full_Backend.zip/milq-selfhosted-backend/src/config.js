import "dotenv/config";

function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable: ${name}`);
  return v;
}

export const config = {
  port: Number(process.env.PORT || 3000),
  databaseUrl: required("DATABASE_URL"),
  jwtSecret: required("JWT_SECRET"),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "30d",
  botHostingBase: process.env.BOT_HOSTING_API_BASE || "https://bot-hosting.net/api/v1",
  botHostingApiKey: required("BOT_HOSTING_API_KEY"),
  corsOrigins: (process.env.CORS_ORIGINS || "*").split(",").map(v => v.trim()),
  maxJsonBody: process.env.MAX_JSON_BODY || "2mb",
  storageDir: process.env.STORAGE_DIR || "/app/storage"
};
